NEONSHARE PC
============
Mirrors this PC's screen to the NeonShare app on your Android phone, over your own Wi-Fi.

1. Double-click "NeonShare PC.bat". The first time it builds NeonSharePC.exe (a few seconds) using the
   C# compiler that comes with Windows, so there is nothing to install.
2. If Windows Firewall asks, tick "Private networks" and click Allow.
3. Open NeonShare on your phone (same Wi-Fi). Your PC shows up; tap it and enter the 6-digit PIN
   shown in the NeonShare PC window.

- Pause sharing: the phone keeps the last picture until you resume.
- New PIN: makes a fresh PIN and disconnects everyone.
- The PIN is stored in %APPDATA%\NeonShare\pin.txt.
- Ports: TCP 47800 (picture), UDP 47801 (so phones can find the PC).
- Everything stays on your local network. The picture isn't encrypted, so use it on your own Wi-Fi.
