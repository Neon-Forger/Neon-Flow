@echo off
title NeonShare PC
cd /d "%~dp0"
rem Builds NeonSharePC.exe with the C# compiler that comes with Windows (first time, or after an update), then starts it.
powershell -NoProfile -Command "if(!(Test-Path 'NeonSharePC.exe') -or (Get-Item 'NeonSharePC.cs').LastWriteTime -gt (Get-Item 'NeonSharePC.exe').LastWriteTime){exit 1}else{exit 0}"
if not errorlevel 1 goto run
set "CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%CSC%" set "CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
if not exist "%CSC%" (
  echo Couldn't find the .NET Framework 4 C# compiler. It normally comes with Windows 10 and 11.
  pause
  exit /b 1
)
echo Building NeonShare PC (a few seconds, first time only)...
"%CSC%" /nologo /target:winexe /optimize+ /out:NeonSharePC.exe /r:System.Windows.Forms.dll /r:System.Drawing.dll NeonSharePC.cs > compile_log.txt 2>&1
if errorlevel 1 (
  type compile_log.txt
  echo.
  echo Build failed. Send compile_log.txt to Claude.
  pause
  exit /b 1
)
:run
start "" "%~dp0NeonSharePC.exe"
