// NeonShare PC: mirrors this PC's screen to the NeonShare app on your phone, over your own Wi-Fi.
//
// How it works
//  - Captures the chosen monitor (with the mouse pointer), scales it to the size the phone asks for, encodes JPEG and
//    streams it over TCP port 47800. Frames are only sent when the screen changed, and at most 2 frames are "in flight"
//    (the phone acknowledges each one), so the picture stays live instead of lagging behind.
//  - The phone finds this PC automatically: a small "I'm here" message is broadcast on UDP port 47801 every second.
//  - A 6-digit PIN (shown in this window) is required to connect. 5 wrong PINs from one address = 60 s lockout.
//  - Nothing leaves your local network: no servers, no accounts.
//
// Written for C# 5 so it compiles with the C# compiler that ships with Windows (.NET Framework 4.x); see the .bat file.

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace NeonShare
{
    static class Native
    {
        [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
        [DllImport("shcore.dll")] public static extern int SetProcessDpiAwareness(int value);
        [DllImport("user32.dll")] public static extern IntPtr GetDC(IntPtr hWnd);
        [DllImport("user32.dll")] public static extern int ReleaseDC(IntPtr hWnd, IntPtr hDC);
        [DllImport("gdi32.dll")] public static extern bool StretchBlt(IntPtr hdcDest, int xDest, int yDest, int wDest, int hDest,
            IntPtr hdcSrc, int xSrc, int ySrc, int wSrc, int hSrc, int rop);
        [DllImport("gdi32.dll")] public static extern int SetStretchBltMode(IntPtr hdc, int mode);
        [DllImport("gdi32.dll")] public static extern bool SetBrushOrgEx(IntPtr hdc, int x, int y, IntPtr pt);
        [DllImport("user32.dll")] public static extern bool GetCursorInfo(ref CURSORINFO pci);
        [DllImport("user32.dll")] public static extern bool GetIconInfo(IntPtr hIcon, out ICONINFO piconinfo);
        [DllImport("user32.dll")] public static extern bool DrawIconEx(IntPtr hdc, int x, int y, IntPtr hIcon, int cx, int cy, int step, IntPtr brush, int flags);
        [DllImport("gdi32.dll")] public static extern bool DeleteObject(IntPtr h);

        public const int SRCCOPY = 0x00CC0020;
        public const int CAPTUREBLT = 0x40000000;
        public const int HALFTONE = 4;
        public const int COLORONCOLOR = 3;
        public const int CURSOR_SHOWING = 1;
        public const int DI_NORMAL = 3;

        [StructLayout(LayoutKind.Sequential)]
        public struct POINT { public int X; public int Y; }
        [StructLayout(LayoutKind.Sequential)]
        public struct CURSORINFO { public int cbSize; public int flags; public IntPtr hCursor; public POINT ptScreenPos; }
        [StructLayout(LayoutKind.Sequential)]
        public struct ICONINFO { public bool fIcon; public int xHotspot; public int yHotspot; public IntPtr hbmMask; public IntPtr hbmColor; }
    }

    /// <summary>Settings and shared state.</summary>
    static class Hub
    {
        public const int TcpPort = 47800;
        public const int UdpPort = 47801;
        public static string Pin = "";
        public static volatile bool Sharing = true;
        public static volatile bool ShowCursor = true;
        public static readonly object Lock = new object();
        public static readonly List<Client> Clients = new List<Client>();
        public static readonly Dictionary<string, int> BadTries = new Dictionary<string, int>();
        public static readonly Dictionary<string, DateTime> LockedUntil = new Dictionary<string, DateTime>();

        static string Folder
        {
            get
            {
                string f = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "NeonShare");
                Directory.CreateDirectory(f);
                return f;
            }
        }

        public static void LoadPin()
        {
            string file = Path.Combine(Folder, "pin.txt");
            try { if (File.Exists(file)) Pin = File.ReadAllText(file).Trim(); } catch { }
            if (Pin.Length != 6) NewPin();
        }

        public static void NewPin()
        {
            byte[] b = new byte[4];
            using (var rng = new System.Security.Cryptography.RNGCryptoServiceProvider()) rng.GetBytes(b);
            Pin = (BitConverter.ToUInt32(b, 0) % 1000000).ToString("D6");
            try { File.WriteAllText(Path.Combine(Folder, "pin.txt"), Pin); } catch { }
            // everyone has to reconnect with the new PIN
            lock (Lock) { foreach (var c in Clients.ToArray()) c.Close(); }
        }

        public static List<string> LocalIps()
        {
            var list = new List<string>();
            try
            {
                foreach (var ni in NetworkInterface.GetAllNetworkInterfaces())
                {
                    if (ni.OperationalStatus != OperationalStatus.Up || ni.NetworkInterfaceType == NetworkInterfaceType.Loopback) continue;
                    foreach (var ua in ni.GetIPProperties().UnicastAddresses)
                        if (ua.Address.AddressFamily == AddressFamily.InterNetwork && !ua.Address.ToString().StartsWith("169.254."))
                            list.Add(ua.Address.ToString());
                }
            }
            catch { }
            return list;
        }

        /// <summary>Subnet broadcast addresses of every active network (for discovery).</summary>
        public static List<IPAddress> Broadcasts()
        {
            var list = new List<IPAddress>();
            try
            {
                foreach (var ni in NetworkInterface.GetAllNetworkInterfaces())
                {
                    if (ni.OperationalStatus != OperationalStatus.Up || ni.NetworkInterfaceType == NetworkInterfaceType.Loopback) continue;
                    foreach (var ua in ni.GetIPProperties().UnicastAddresses)
                    {
                        if (ua.Address.AddressFamily != AddressFamily.InterNetwork || ua.IPv4Mask == null) continue;
                        byte[] ip = ua.Address.GetAddressBytes(), mask = ua.IPv4Mask.GetAddressBytes(), bc = new byte[4];
                        for (int i = 0; i < 4; i++) bc[i] = (byte)(ip[i] | ~mask[i]);
                        list.Add(new IPAddress(bc));
                    }
                }
            }
            catch { }
            list.Add(IPAddress.Broadcast);
            return list;
        }
    }

    /// <summary>One connected phone: its own capture loop and settings.</summary>
    class Client
    {
        readonly TcpClient tcp;
        readonly NetworkStream net;
        public readonly string Address;
        public string Name = "Phone";
        volatile bool open = true;
        public volatile int Width = 1280;
        public volatile int Quality = 60;
        public volatile int Fps = 30;
        public volatile int Monitor = 0;
        int sentId = 0;
        volatile int ackedId = 0;
        readonly Dictionary<int, long> sentAt = new Dictionary<int, long>();
        readonly Stopwatch clock = Stopwatch.StartNew();
        public volatile int RttMs = 0;
        public volatile float FpsNow = 0;
        public volatile float Mbps = 0;
        public volatile bool forceFrame = true;

        public Client(TcpClient t)
        {
            tcp = t; tcp.NoDelay = true; tcp.SendBufferSize = 512 * 1024;
            net = t.GetStream();
            Address = ((IPEndPoint)t.Client.RemoteEndPoint).Address.ToString();
        }

        public bool IsOpen { get { return open; } }

        public void Close()
        {
            open = false;
            try { tcp.Close(); } catch { }
        }

        static string ReadLine(Stream s, int max)
        {
            var sb = new StringBuilder();
            while (sb.Length < max)
            {
                int b = s.ReadByte();
                if (b < 0) return null;
                if (b == '\n') break;
                if (b != '\r') sb.Append((char)b);
            }
            return sb.ToString();
        }

        static Dictionary<string, string> Parse(string line)
        {
            var d = new Dictionary<string, string>();
            foreach (var part in line.Split(' '))
            {
                int i = part.IndexOf('=');
                if (i > 0) d[part.Substring(0, i)] = Uri.UnescapeDataString(part.Substring(i + 1));
            }
            return d;
        }

        void WriteText(string s)
        {
            byte[] b = Encoding.UTF8.GetBytes(s + "\n");
            lock (net) net.Write(b, 0, b.Length);
        }

        /// <summary>Handshake, then two threads: commands in, frames out.</summary>
        public void Run()
        {
            try
            {
                tcp.ReceiveTimeout = 10000;
                string hello = ReadLine(net, 600);
                if (hello == null || !hello.StartsWith("NEONSHARE1")) { Close(); return; }
                var p = Parse(hello);
                DateTime until;
                lock (Hub.Lock)
                {
                    if (Hub.LockedUntil.TryGetValue(Address, out until) && until > DateTime.Now)
                    {
                        WriteText("NO locked " + (int)(until - DateTime.Now).TotalSeconds); Close(); return;
                    }
                }
                string pin; p.TryGetValue("pin", out pin);
                if (pin != Hub.Pin)
                {
                    lock (Hub.Lock)
                    {
                        int n; Hub.BadTries.TryGetValue(Address, out n); n++;
                        Hub.BadTries[Address] = n;
                        if (n >= 5) { Hub.LockedUntil[Address] = DateTime.Now.AddSeconds(60); Hub.BadTries[Address] = 0; }
                    }
                    WriteText("NO pin"); Close(); return;
                }
                lock (Hub.Lock) Hub.BadTries.Remove(Address);
                string v;
                if (p.TryGetValue("name", out v)) Name = v.Length > 40 ? v.Substring(0, 40) : v;
                if (p.TryGetValue("w", out v)) Width = Clamp(ToInt(v, 1280), 320, 3840);
                if (p.TryGetValue("q", out v)) Quality = Clamp(ToInt(v, 60), 10, 95);
                if (p.TryGetValue("fps", out v)) Fps = Clamp(ToInt(v, 30), 1, 60);
                var screens = Screen.AllScreens;
                var sb = new StringBuilder("OK pc=" + Uri.EscapeDataString(Environment.MachineName) + " monitors=" + screens.Length);
                for (int i = 0; i < screens.Length; i++)
                    sb.Append(" m" + i + "=" + screens[i].Bounds.Width + "x" + screens[i].Bounds.Height + (screens[i].Primary ? "p" : ""));
                WriteText(sb.ToString());
                tcp.ReceiveTimeout = 0;
                lock (Hub.Lock) Hub.Clients.Add(this);
                var reader = new Thread(ReadLoop); reader.IsBackground = true; reader.Start();
                SendLoop();
            }
            catch { }
            finally
            {
                Close();
                lock (Hub.Lock) Hub.Clients.Remove(this);
            }
        }

        static int ToInt(string s, int d) { int r; return int.TryParse(s, out r) ? r : d; }
        static int Clamp(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }

        void ReadLoop()
        {
            try
            {
                while (open)
                {
                    string line = ReadLine(net, 200);
                    if (line == null) break;
                    string[] a = line.Split(' ');
                    if (a.Length == 0) continue;
                    int n = a.Length > 1 ? ToInt(a[1], -1) : -1;
                    switch (a[0])
                    {
                        case "ACK":
                            if (n > ackedId) ackedId = n;
                            long t0;
                            lock (sentAt) { if (sentAt.TryGetValue(n, out t0)) { RttMs = (int)(clock.ElapsedMilliseconds - t0); sentAt.Remove(n); } }
                            break;
                        case "Q": if (n > 0) { Quality = Clamp(n, 10, 95); forceFrame = true; } break;
                        case "W": if (n > 0) { Width = Clamp(n, 320, 3840); forceFrame = true; } break;
                        case "FPS": if (n > 0) Fps = Clamp(n, 1, 60); break;
                        case "M": if (n >= 0) { Monitor = n; forceFrame = true; } break;
                        case "BYE": open = false; break;
                    }
                }
            }
            catch { }
            Close();
        }

        void SendLoop()
        {
            var cap = new Capturer();
            var ms = new MemoryStream(1 << 20);
            int frames = 0; long bytes = 0; long statT = clock.ElapsedMilliseconds;
            long lastSend = 0;
            ulong lastHash = 0;
            while (open)
            {
                long frameStart = clock.ElapsedMilliseconds;
                // don't run ahead of the phone: at most 2 frames waiting for an ACK
                if (sentId - ackedId >= 2)
                {
                    if (clock.ElapsedMilliseconds - lastSend > 3000) { ackedId = sentId; }   // lost ACK: carry on
                    Thread.Sleep(2); continue;
                }
                if (!Hub.Sharing) { Thread.Sleep(200); SendKeepAlive(ref lastSend); continue; }

                var screens = Screen.AllScreens;
                var scr = screens[Monitor < screens.Length ? Monitor : 0];
                Bitmap bmp = cap.Grab(scr.Bounds, Width, Hub.ShowCursor);
                ulong h = Capturer.Hash(bmp);
                bool changed = h != lastHash || forceFrame;
                if (changed || clock.ElapsedMilliseconds - lastSend > 2000)
                {
                    if (!changed) { SendKeepAlive(ref lastSend); }
                    else
                    {
                        lastHash = h; forceFrame = false;
                        ms.SetLength(0);
                        Capturer.Jpeg(bmp, ms, Quality);
                        int id = ++sentId;
                        lock (sentAt) { sentAt[id] = clock.ElapsedMilliseconds; if (sentAt.Count > 50) sentAt.Clear(); }
                        // header: type(1) id(4) rtt(4) width(2) height(2) length(4), big-endian
                        byte[] head = new byte[17];
                        head[0] = 1;
                        PutInt(head, 1, id); PutInt(head, 5, RttMs);
                        head[9] = (byte)(bmp.Width >> 8); head[10] = (byte)bmp.Width;
                        head[11] = (byte)(bmp.Height >> 8); head[12] = (byte)bmp.Height;
                        PutInt(head, 13, (int)ms.Length);
                        lock (net)
                        {
                            net.Write(head, 0, head.Length);
                            net.Write(ms.GetBuffer(), 0, (int)ms.Length);
                        }
                        lastSend = clock.ElapsedMilliseconds;
                        frames++; bytes += ms.Length + head.Length;
                    }
                }
                long now = clock.ElapsedMilliseconds;
                if (now - statT >= 1000)
                {
                    FpsNow = frames * 1000f / (now - statT); Mbps = bytes * 8f / 1000f / (now - statT);
                    frames = 0; bytes = 0; statT = now;
                }
                int wait = (int)(1000 / Math.Max(1, Fps) - (clock.ElapsedMilliseconds - frameStart));
                if (wait > 0) Thread.Sleep(wait);
            }
            cap.Dispose();
        }

        void SendKeepAlive(ref long lastSend)
        {
            if (clock.ElapsedMilliseconds - lastSend < 2000) return;
            byte[] head = new byte[17]; head[0] = 2;
            PutInt(head, 5, RttMs);
            lock (net) net.Write(head, 0, head.Length);
            lastSend = clock.ElapsedMilliseconds;
        }

        static void PutInt(byte[] b, int o, int v)
        {
            b[o] = (byte)(v >> 24); b[o + 1] = (byte)(v >> 16); b[o + 2] = (byte)(v >> 8); b[o + 3] = (byte)v;
        }
    }

    /// <summary>Screen capture: one GDI StretchBlt straight from the screen into a reused bitmap (fast), plus the pointer.</summary>
    class Capturer : IDisposable
    {
        Bitmap bmp;
        static ImageCodecInfo jpegCodec;

        public Bitmap Grab(Rectangle src, int maxWidth, bool cursor)
        {
            int w = Math.Min(maxWidth, src.Width);
            int h = (int)Math.Round((double)src.Height * w / src.Width);
            w &= ~1; h &= ~1;
            if (bmp == null || bmp.Width != w || bmp.Height != h)
            {
                if (bmp != null) bmp.Dispose();
                bmp = new Bitmap(w, h, PixelFormat.Format24bppRgb);
            }
            using (Graphics g = Graphics.FromImage(bmp))
            {
                IntPtr dst = g.GetHdc();
                IntPtr scr = Native.GetDC(IntPtr.Zero);
                try
                {
                    bool same = w == src.Width;
                    Native.SetStretchBltMode(dst, same ? Native.COLORONCOLOR : Native.HALFTONE);
                    Native.SetBrushOrgEx(dst, 0, 0, IntPtr.Zero);
                    Native.StretchBlt(dst, 0, 0, w, h, scr, src.X, src.Y, src.Width, src.Height, Native.SRCCOPY | Native.CAPTUREBLT);
                    if (cursor) DrawCursor(dst, src, (double)w / src.Width);
                }
                finally
                {
                    Native.ReleaseDC(IntPtr.Zero, scr);
                    g.ReleaseHdc(dst);
                }
            }
            return bmp;
        }

        static void DrawCursor(IntPtr hdc, Rectangle src, double scale)
        {
            var ci = new Native.CURSORINFO();
            ci.cbSize = Marshal.SizeOf(typeof(Native.CURSORINFO));
            if (!Native.GetCursorInfo(ref ci) || ci.flags != Native.CURSOR_SHOWING) return;
            if (!src.Contains(ci.ptScreenPos.X, ci.ptScreenPos.Y)) return;
            Native.ICONINFO ii;
            int hx = 0, hy = 0;
            if (Native.GetIconInfo(ci.hCursor, out ii))
            {
                hx = ii.xHotspot; hy = ii.yHotspot;
                if (ii.hbmMask != IntPtr.Zero) Native.DeleteObject(ii.hbmMask);
                if (ii.hbmColor != IntPtr.Zero) Native.DeleteObject(ii.hbmColor);
            }
            // keep the pointer readable on a small screen: never smaller than 60% of normal
            double s = Math.Max(scale, 0.6);
            int size = (int)(32 * s);
            int x = (int)((ci.ptScreenPos.X - src.X) * scale - hx * s);
            int y = (int)((ci.ptScreenPos.Y - src.Y) * scale - hy * s);
            Native.DrawIconEx(hdc, x, y, ci.hCursor, size, size, 0, IntPtr.Zero, Native.DI_NORMAL);
        }

        /// <summary>Cheap fingerprint of the picture (a grid of sample pixels) to skip unchanged frames.</summary>
        public static ulong Hash(Bitmap b)
        {
            var data = b.LockBits(new Rectangle(0, 0, b.Width, b.Height), ImageLockMode.ReadOnly, PixelFormat.Format24bppRgb);
            ulong h = 1469598103934665603UL;
            try
            {
                int stride = data.Stride;
                byte[] row = new byte[stride];
                int stepY = Math.Max(1, b.Height / 90);
                for (int y = 0; y < b.Height; y += stepY)
                {
                    Marshal.Copy(data.Scan0 + y * stride, row, 0, stride);
                    for (int x = 0; x < stride; x += 7) { h ^= row[x]; h *= 1099511628211UL; }
                }
            }
            finally { b.UnlockBits(data); }
            return h;
        }

        public static void Jpeg(Bitmap b, Stream s, int quality)
        {
            if (jpegCodec == null)
                foreach (var c in ImageCodecInfo.GetImageEncoders()) if (c.FormatID == ImageFormat.Jpeg.Guid) jpegCodec = c;
            using (var ep = new EncoderParameters(1))
            {
                ep.Param[0] = new EncoderParameter(System.Drawing.Imaging.Encoder.Quality, (long)quality);
                b.Save(s, jpegCodec, ep);
            }
        }

        public void Dispose() { if (bmp != null) bmp.Dispose(); bmp = null; }
    }

    /// <summary>TCP server + UDP discovery.</summary>
    static class Server
    {
        static TcpListener listener;
        public static string Error = "";

        public static void Start()
        {
            var t = new Thread(Accept); t.IsBackground = true; t.Start();
            var d = new Thread(Discovery); d.IsBackground = true; d.Start();
        }

        static void Accept()
        {
            try
            {
                listener = new TcpListener(IPAddress.Any, Hub.TcpPort);
                listener.Start();
                while (true)
                {
                    TcpClient c = listener.AcceptTcpClient();
                    var client = new Client(c);
                    lock (Hub.Lock) { if (Hub.Clients.Count >= 4) { c.Close(); continue; } }
                    var th = new Thread(client.Run); th.IsBackground = true; th.Start();
                }
            }
            catch (Exception e) { Error = "Couldn't open port " + Hub.TcpPort + ": " + e.Message; }
        }

        /// <summary>Announce "NEONSHARE|name|port" every second, and answer "NEONSHARE?" queries right away.</summary>
        static void Discovery()
        {
            UdpClient udp = null;
            try
            {
                udp = new UdpClient();
                udp.Client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);
                udp.Client.Bind(new IPEndPoint(IPAddress.Any, Hub.UdpPort));
                udp.EnableBroadcast = true;
            }
            catch (Exception e) { Error = "Discovery is off (" + e.Message + "). Type this PC's address on the phone."; return; }
            byte[] msg = Encoding.UTF8.GetBytes("NEONSHARE|" + Environment.MachineName + "|" + Hub.TcpPort);
            var listen = new Thread(delegate ()
            {
                while (true)
                {
                    try
                    {
                        var from = new IPEndPoint(IPAddress.Any, 0);
                        byte[] q = udp.Receive(ref from);
                        if (Encoding.UTF8.GetString(q).StartsWith("NEONSHARE?")) udp.Send(msg, msg.Length, from);
                    }
                    catch { Thread.Sleep(200); }
                }
            });
            listen.IsBackground = true; listen.Start();
            while (true)
            {
                foreach (var bc in Hub.Broadcasts())
                {
                    try { udp.Send(msg, msg.Length, new IPEndPoint(bc, Hub.UdpPort)); } catch { }
                }
                Thread.Sleep(1000);
            }
        }
    }

    /// <summary>The window: PIN, addresses, who's watching, controls.</summary>
    class MainForm : Form
    {
        readonly Label pinLabel = new Label(), ipLabel = new Label(), status = new Label(), clientsLabel = new Label();
        readonly Button pauseBtn = new Button(), pinBtn = new Button();
        readonly CheckBox cursorBox = new CheckBox();
        readonly System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();
        static readonly Color Bg = Color.FromArgb(2, 8, 20), Cyan = Color.FromArgb(46, 230, 255), Pink = Color.FromArgb(255, 43, 214),
            Muted = Color.FromArgb(125, 147, 184), Text1 = Color.FromArgb(230, 244, 255), Green = Color.FromArgb(61, 255, 154);

        public MainForm()
        {
            Text = "NeonShare PC";
            BackColor = Bg; ForeColor = Text1;
            Font = new Font("Segoe UI", 10f);
            FormBorderStyle = FormBorderStyle.FixedSingle; MaximizeBox = false;
            ClientSize = new Size(460, 470);
            StartPosition = FormStartPosition.CenterScreen;
            try { Icon = MakeIcon(); } catch { }

            var title = new Label { Text = "NEONSHARE", ForeColor = Cyan, Font = new Font("Consolas", 26f, FontStyle.Bold), AutoSize = true, Location = new Point(24, 18) };
            var sub = new Label { Text = "Mirror this PC to your phone", ForeColor = Muted, AutoSize = true, Location = new Point(28, 66) };
            var pinTitle = new Label { Text = "PIN FOR YOUR PHONE", ForeColor = Pink, Font = new Font("Consolas", 10f, FontStyle.Bold), AutoSize = true, Location = new Point(28, 104) };
            pinLabel.ForeColor = Text1; pinLabel.Font = new Font("Consolas", 40f, FontStyle.Bold); pinLabel.AutoSize = true; pinLabel.Location = new Point(22, 122);
            ipLabel.ForeColor = Muted; ipLabel.AutoSize = false; ipLabel.Size = new Size(410, 46); ipLabel.Location = new Point(28, 196);
            status.ForeColor = Green; status.Font = new Font("Segoe UI", 11f, FontStyle.Bold); status.AutoSize = false; status.Size = new Size(410, 26); status.Location = new Point(28, 250);
            clientsLabel.ForeColor = Text1; clientsLabel.AutoSize = false; clientsLabel.Size = new Size(410, 84); clientsLabel.Location = new Point(28, 278);

            Style(pauseBtn, "Pause sharing", Cyan); pauseBtn.Location = new Point(28, 372); pauseBtn.Size = new Size(196, 40);
            pauseBtn.Click += delegate { Hub.Sharing = !Hub.Sharing; pauseBtn.Text = Hub.Sharing ? "Pause sharing" : "Resume sharing"; };
            Style(pinBtn, "New PIN", Pink); pinBtn.Location = new Point(236, 372); pinBtn.Size = new Size(196, 40);
            pinBtn.Click += delegate { Hub.NewPin(); pinLabel.Text = Spaced(Hub.Pin); };
            cursorBox.Text = "Show my mouse pointer"; cursorBox.Checked = true; cursorBox.ForeColor = Text1; cursorBox.AutoSize = true; cursorBox.Location = new Point(30, 424);
            cursorBox.CheckedChanged += delegate { Hub.ShowCursor = cursorBox.Checked; };

            Controls.AddRange(new Control[] { title, sub, pinTitle, pinLabel, ipLabel, status, clientsLabel, pauseBtn, pinBtn, cursorBox });
            pinLabel.Text = Spaced(Hub.Pin);
            timer.Interval = 1000; timer.Tick += delegate { Refresh2(); }; timer.Start();
            Refresh2();
        }

        static string Spaced(string pin) { return pin.Length == 6 ? pin.Substring(0, 3) + " " + pin.Substring(3) : pin; }

        static void Style(Button b, string text, Color c)
        {
            b.Text = text; b.FlatStyle = FlatStyle.Flat; b.ForeColor = c; b.BackColor = Color.FromArgb(7, 21, 51);
            b.FlatAppearance.BorderColor = c; b.FlatAppearance.BorderSize = 2; b.Font = new Font("Segoe UI", 10f, FontStyle.Bold);
            b.Cursor = Cursors.Hand;
        }

        void Refresh2()
        {
            var ips = Hub.LocalIps();
            ipLabel.Text = "This PC: " + Environment.MachineName + "\n" + (ips.Count > 0 ? string.Join("  ·  ", ips.ToArray()) : "not connected to a network");
            Client[] cs;
            lock (Hub.Lock) cs = Hub.Clients.ToArray();
            if (Server.Error.Length > 0) { status.ForeColor = Color.FromArgb(255, 194, 61); status.Text = Server.Error; }
            else if (!Hub.Sharing) { status.ForeColor = Color.FromArgb(255, 194, 61); status.Text = "Paused: phones see a frozen picture"; }
            else if (cs.Length == 0) { status.ForeColor = Muted; status.Text = "Waiting for your phone… open NeonShare on it"; }
            else { status.ForeColor = Green; status.Text = "● Sharing your screen"; }
            var sb = new StringBuilder();
            foreach (var c in cs)
                sb.AppendLine(c.Name + " (" + c.Address + ")  " + c.FpsNow.ToString("0") + " fps · " + c.Mbps.ToString("0.0") + " Mbps · " + c.RttMs + " ms");
            clientsLabel.Text = sb.ToString();
        }

        static Icon MakeIcon()
        {
            var b = new Bitmap(32, 32);
            using (var g = Graphics.FromImage(b))
            {
                g.SmoothingMode = SmoothingMode.AntiAlias;
                g.Clear(Color.FromArgb(2, 8, 20));
                using (var p = new Pen(Cyan, 3)) g.DrawRectangle(p, 3, 6, 26, 17);
                using (var p = new Pen(Pink, 3)) g.DrawLine(p, 11, 27, 21, 27);
            }
            return Icon.FromHandle(b.GetHicon());
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            lock (Hub.Lock) { foreach (var c in Hub.Clients.ToArray()) c.Close(); }
            base.OnFormClosing(e);
        }
    }

    static class Program
    {
        [STAThread]
        static void Main()
        {
            // capture real pixels on high-DPI screens (otherwise Windows hands us a scaled-down, partial picture)
            try { if (Native.SetProcessDpiAwareness(2) != 0) Native.SetProcessDPIAware(); } catch { try { Native.SetProcessDPIAware(); } catch { } }
            bool created;
            using (var m = new Mutex(true, "NeonSharePC-single", out created))
            {
                if (!created) { MessageBox.Show("NeonShare PC is already running.", "NeonShare"); return; }
                Hub.LoadPin();
                Server.Start();
                Application.EnableVisualStyles();
                Application.Run(new MainForm());
            }
        }
    }
}
